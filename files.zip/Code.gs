/**
 * Milagro Ferm Log — Apps Script backend
 * ---------------------------------------
 * Deploy this as a Web App (Deploy > New deployment > Web app).
 *   Execute as:  Me
 *   Who has access: Anyone with the link
 * Copy the resulting /exec URL into CONFIG.API_URL in ferm.js.
 *
 * FERM_LOG_SHEET_ID below is a placeholder. Create Ferm_Master_Log_2026
 * inside your 2026 Harvest folder (a plain Google Sheet with one header
 * row: Date, Time, Lot ID, Temp (°F), Brix, Notes, Entered By, Source),
 * then paste its file ID in below. The ID is the long string in the
 * sheet's URL: docs.google.com/spreadsheets/d/THIS_PART/edit
 */

const FERM_LOG_SHEET_ID = "PASTE_2026_FERM_MASTER_LOG_SHEET_ID_HERE";
const TIMEZONE = "America/Denver";
const SOURCE_TAG = "PWA";

function doGet(e) {
  return jsonResponse({ ok: true, message: "Milagro Ferm Log backend is running." });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    if (body.action !== "log") {
      return jsonResponse({ ok: false, error: "Unknown action" });
    }
    appendReading(body);
    return jsonResponse({ ok: true });
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err) });
  }
}

// ---------------------------------------------------------------
// Append a reading to the Ferm Master Log
// ---------------------------------------------------------------
function appendReading(body) {
  const lot = String(body.lot || "").trim();
  const temp = String(body.temp || "").trim();
  const brix = String(body.brix || "").trim();
  if (!lot) throw new Error("Missing lot");
  if (!temp && !brix) throw new Error("Need at least a temperature or Brix reading");

  const ss = SpreadsheetApp.openById(FERM_LOG_SHEET_ID);
  const sheet = ss.getSheets()[0];
  const values = sheet.getDataRange().getValues();
  const headerRowIndex = findHeaderRow(values, "Lot ID");
  const headers = headerRowIndex !== -1
    ? values[headerRowIndex].map((h) => String(h).trim())
    : ["Date", "Time", "Lot ID", "Temp (°F)", "Brix", "Notes", "Entered By", "Source"];

  const dateStr = formatDateForSheet(body.date);
  const timeStr = formatTimeForSheet(body.time);

  const fieldMap = {
    "Date": dateStr,
    "Time": timeStr,
    "Lot ID": lot,
    "Temp (°F)": temp,
    "Brix": brix,
    "Notes": String(body.notes || "").trim(),
    "Entered By": String(body.name || "").trim(),
    "Source": SOURCE_TAG,
  };

  const row = headers.map((h) => (h in fieldMap ? fieldMap[h] : ""));
  sheet.appendRow(row);
}

// Frontend sends the date as "YYYY-MM-DD" (native <input type="date">) and
// time as "HH:MM" 24-hour (native <input type="time">). The existing log
// uses "MM/dd/yy" and an hour with no leading zero, e.g. "9:47" not "09:47".
function formatDateForSheet(dateStr) {
  if (!dateStr) return Utilities.formatDate(new Date(), TIMEZONE, "MM/dd/yy");
  const [y, m, d] = dateStr.split("-");
  return `${m}/${d}/${y.slice(2)}`;
}

function formatTimeForSheet(timeStr) {
  if (!timeStr) return Utilities.formatDate(new Date(), TIMEZONE, "H:mm");
  const [h, m] = timeStr.split(":");
  return `${parseInt(h, 10)}:${m}`;
}

// ---------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------
// Some of these workbooks have a title/config block above the real header
// row, so search the first ~10 rows for the row that contains expectedCol.
function findHeaderRow(values, expectedCol) {
  const scanRows = Math.min(values.length, 10);
  for (let i = 0; i < scanRows; i++) {
    const row = values[i].map((c) => String(c).trim());
    if (row.indexOf(expectedCol) !== -1) return i;
  }
  return -1;
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON
  );
}
