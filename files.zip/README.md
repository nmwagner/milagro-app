# Milagro Cellar &amp; Vineyard

A mobile PWA hub for cellar and vineyard data entry, starting with fermentation logging. No login required, same GitHub Pages + Apps Script pattern as your wine cellar app.

## What it does

- Landing page has two sections: **Cellar Management** (Fermentation Log, live) and **Vineyard Management** (Irrigation Log, placeholder, taps just show a "coming soon" message for now).
- Fermentation Log page: pick a variety, then a lot number, and the app builds the lot code itself (e.g. Chardonnay + 3 → `CH26-03`). Date and time prefill to right now and are still editable, for backfilling a reading logged a few minutes late. Temp and Brix are locked to numeric-only input. Entered by defaults to quick-pick buttons for Max, Laura, and Amy, or type any other name.
- Writes straight into a new sheet, `Ferm_Master_Log_2026`, inside your 2026 Harvest folder, tagged `Source = PWA`.
- Works offline: a failed submit queues locally on the phone and retries automatically once signal comes back.

## 1. Create the 2026 log sheet

I wasn't able to create this one directly, Drive write access needs an approval step I don't have from here. Takes under a minute by hand:

1. Open your **2026 Harvest** folder in Drive.
2. New > Google Sheets. Name it `Ferm_Master_Log_2026`.
3. In row 1, enter these eight headers exactly: `Date`, `Time`, `Lot ID`, `Temp (°F)`, `Brix`, `Notes`, `Entered By`, `Source`.
4. Copy the sheet's ID out of its URL: `docs.google.com/spreadsheets/d/`**`THIS_PART`**`/edit`

## 2. Deploy the backend (Apps Script)

1. Go to [script.google.com](https://script.google.com) and create a new project.
2. Delete the placeholder code and paste in `Code.gs`.
3. Paste the sheet ID from step 1 into `FERM_LOG_SHEET_ID` at the top.
4. **Deploy > New deployment > Web app.**
   - Execute as: **Me**
   - Who has access: **Anyone**
5. Copy the resulting `/exec` URL.
6. Open `ferm.js` and paste that URL into `CONFIG.API_URL` at the top of the file.

Sanity check: paste the `/exec` URL into a browser tab. You should see `{"ok":true,"message":"Milagro Ferm Log backend is running."}`.

## 3. Host the frontend

Same GitHub Desktop flow as before: drop everything below into your `ferm-log` folder inside the wine-cellar repo, replacing what's there, then commit and push.

```
ferm-log/
  index.html        (hub — Cellar Management / Vineyard Management)
  ferm-log.html      (the fermentation log form)
  styles.css
  common.js
  hub.js
  ferm.js
  manifest.json
  service-worker.js
  icons/
```

`Code.gs` doesn't get uploaded, it only lives in the Apps Script project from step 2.

## 4. Test it

Visit `nmwagner.github.io/wine-cellar/ferm-log/`. You should land on the hub. Tap Fermentation Log, run through a real entry (pick a variety and lot, enter a temp or Brix, tap a name), and confirm it lands correctly in `Ferm_Master_Log_2026`. Try airplane mode too, and confirm it queues and syncs once you reconnect. Tap Irrigation Log and confirm you get the "coming soon" toast.

If you already have the wine-cellar app installed to your home screen from before, you may need to remove and re-add it, or force-refresh once, since the service worker cache name changed (`fermlog-v1` → `milagro-app-v2`) specifically so old cached files get replaced instead of lingering.

## Notes

- The lot picker no longer depends on `Lot_Registry` at all, variety and lot number are both fixed local choices, so the form works the same online or off, and doesn't care whether Max has gotten around to registering the lot yet.
- Entries write through regardless of whether that lot code exists anywhere else yet. No cross-check against the registry.
- Vineyard Management is a placeholder section for now. When you're ready to spec out Irrigation Log (or anything else in that section), it slots into the same hub pattern.
